using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Category
{
    public class DeleteModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public CategoryViewModel Category { get; set; } = new();

        public DeleteModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.GetAsync($"api/category/{id}");
            if (response.IsSuccessStatusCode)
            {
                Category = await response.Content.ReadFromJsonAsync<CategoryViewModel>();
                return Page();
            }

            TempData["ErrorMessage"] = "Category not found.";
            return RedirectToPage("Index");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.DeleteAsync($"api/category/{Category.CategoryId}");
            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Category deleted successfully.";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            TempData["ErrorMessage"] = "Error deleting category. Please try again.";
            return RedirectToPage("Index");
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
