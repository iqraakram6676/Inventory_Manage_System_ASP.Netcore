using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Category
{
    public class IndexModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public List<CategoryViewModel> Categories { get; set; } = new();

        public IndexModel(IHttpClientFactory httpClientFactory,
                          IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnGetAsync()
        {
            try
            {
                await AddJwtTokenToHeader();

                var response = await _httpClient.GetAsync("api/category");

                if (response.IsSuccessStatusCode)
                {
                    Categories = await response.Content.ReadFromJsonAsync<List<CategoryViewModel>>() ?? new List<CategoryViewModel>();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    TempData["ErrorMessage"] = $"API Error: {response.StatusCode} - {errorContent}";
                }
            }
            catch (HttpRequestException ex)
            {
                TempData["ErrorMessage"] = $"Network error: {ex.Message}";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Unexpected error: {ex.Message}";
            }
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            await AddJwtTokenToHeader();

            var response = await _httpClient.DeleteAsync($"api/category/{id}");

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Category deleted successfully";
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }
            else
            {
                TempData["ErrorMessage"] = "Failed to delete category";
            }

            return RedirectToPage();
        }

        private async Task AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");

            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
