using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Inventory_Management_System_Web.Pages
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
