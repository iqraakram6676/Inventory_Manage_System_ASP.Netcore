using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Inventory_Management_System_Web.Pages
{
    public class LoginModel : PageModel
    {
        private readonly HttpClient _httpClient;

        public LoginModel(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
        }

        [BindProperty]
        public LoginViewModel LoginData { get; set; } = new LoginViewModel();

        public string ErrorMessage { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var response = await _httpClient.PostAsJsonAsync("api/auth/login", LoginData);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<LoginResponse>();

                
                HttpContext.Session.SetString("JwtToken", result!.Token);
                HttpContext.Session.SetString("Username", result.Username);
                HttpContext.Session.SetString("UserRole", result.Role);

                
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, result.Username ?? ""),
                    new Claim(ClaimTypes.Role, result.Role ?? ""), 
                    new Claim("AccessToken", result.Token ?? "")    
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                // Sign in with cookie authentication
                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    new AuthenticationProperties
                    {
                        IsPersistent = true, // Remember me functionality
                        ExpiresUtc = DateTime.UtcNow.AddHours(2) // Cookie expiry
                    });

                return RedirectToPage("/Home/Dashboard");
            }

            ErrorMessage = "Invalid email or password";
            return Page();
        }

        private class LoginResponse
        {
            public string Token { get; set; } = string.Empty;
            public string Username { get; set; } = string.Empty;
            public string Role { get; set; } = string.Empty;
            public string Email { get; set; } = string.Empty;
        }
    }
}
