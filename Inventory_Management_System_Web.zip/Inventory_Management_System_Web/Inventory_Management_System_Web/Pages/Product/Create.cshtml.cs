using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Product
{
    public class CreateModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public ProductViewModel Product { get; set; } = new();

        public List<SelectListItem> CategoryList { get; set; } = new();
        public List<SelectListItem> SupplierList { get; set; } = new();

        public CreateModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnGetAsync()
        {
            AddJwtTokenToHeader();

            // Load categories
            var categoriesResponse = await _httpClient.GetAsync("api/category");
            if (categoriesResponse.IsSuccessStatusCode)
            {
                var categories = await categoriesResponse.Content.ReadFromJsonAsync<List<CategoryViewModel>>();
                CategoryList = categories?.Select(c => new SelectListItem
                {
                    Value = c.CategoryId.ToString(),
                    Text = c.CategoryName
                }).ToList() ?? new List<SelectListItem>();
            }

            // Load suppliers
            var suppliersResponse = await _httpClient.GetAsync("api/supplier");
            if (suppliersResponse.IsSuccessStatusCode)
            {
                var suppliers = await suppliersResponse.Content.ReadFromJsonAsync<List<SupplierViewModel>>();
                SupplierList = suppliers?.Select(s => new SelectListItem
                {
                    Value = s.SupplierId.ToString(),
                    Text = s.SupplierName
                }).ToList() ?? new List<SelectListItem>();
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await OnGetAsync(); // Reload dropdowns
                return Page();
            }

            AddJwtTokenToHeader();

            var response = await _httpClient.PostAsJsonAsync("api/product", Product);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Product created successfully.";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            ModelState.AddModelError(string.Empty, "Error creating product. Please try again.");
            await OnGetAsync(); // reload dropdowns
            return Page();
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
