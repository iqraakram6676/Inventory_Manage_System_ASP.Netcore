using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Product
{
    public class DeleteModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public ProductViewModel Product { get; set; } = new();

        public DeleteModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            // Get Product
            var productResponse = await _httpClient.GetAsync($"api/product/{id}");
            if (!productResponse.IsSuccessStatusCode)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToPage("Index");
            }

            Product = await productResponse.Content.ReadFromJsonAsync<ProductViewModel>();

            // Get Category Name
            var categoryResponse = await _httpClient.GetAsync($"api/category/{Product.CategoryId}");
            if (categoryResponse.IsSuccessStatusCode)
            {
                var category = await categoryResponse.Content.ReadFromJsonAsync<CategoryViewModel>();
                Product.CategoryName = category?.CategoryName;
            }

            // Get Supplier Name
            var supplierResponse = await _httpClient.GetAsync($"api/supplier/{Product.SupplierId}");
            if (supplierResponse.IsSuccessStatusCode)
            {
                var supplier = await supplierResponse.Content.ReadFromJsonAsync<SupplierViewModel>();
                Product.SupplierName = supplier?.SupplierName;
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.DeleteAsync($"api/product/{Product.ProductId}");
            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Product deleted successfully.";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            TempData["ErrorMessage"] = "Error deleting product. Please try again.";
            return RedirectToPage("Index");
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
