using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Product
{
    public class EditModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public ProductViewModel Product { get; set; } = new();

        public List<SelectListItem> CategoryList { get; set; } = new();
        public List<SelectListItem> SupplierList { get; set; } = new();

        public EditModel(IHttpClientFactory httpClientFactory,
                         IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            // Load Product
            var productResponse = await _httpClient.GetAsync($"api/product/{id}");
            if (productResponse.IsSuccessStatusCode)
            {
                Product = await productResponse.Content.ReadFromJsonAsync<ProductViewModel>();
            }
            else
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToPage("Index");
            }

            // Load Categories
            var categoriesResponse = await _httpClient.GetAsync("api/category");
            if (categoriesResponse.IsSuccessStatusCode)
            {
                var categories = await categoriesResponse.Content.ReadFromJsonAsync<List<CategoryViewModel>>();
                CategoryList = categories?
                    .Select(c => new SelectListItem
                    {
                        Value = c.CategoryId.ToString(),
                        Text = c.CategoryName,
                        Selected = c.CategoryId == Product.CategoryId
                    })
                    .ToList() ?? new List<SelectListItem>();
            }

            // Load Suppliers
            var suppliersResponse = await _httpClient.GetAsync("api/supplier");
            if (suppliersResponse.IsSuccessStatusCode)
            {
                var suppliers = await suppliersResponse.Content.ReadFromJsonAsync<List<SupplierViewModel>>();
                SupplierList = suppliers?
                    .Select(s => new SelectListItem
                    {
                        Value = s.SupplierId.ToString(),
                        Text = s.SupplierName,
                        Selected = s.SupplierId == Product.SupplierId
                    })
                    .ToList() ?? new List<SelectListItem>();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return await OnGetAsync(Product.ProductId); // reload dropdowns
            }

            // Get role from session
            var role = _httpContextAccessor.HttpContext?.Session.GetString("UserRole");

            // If Employee, restrict editable fields
            if (role == "Employee")
            {
                AddJwtTokenToHeader();
                var existingResponse = await _httpClient.GetAsync($"api/product/{Product.ProductId}");
                if (!existingResponse.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(string.Empty, "Product not found.");
                    return await OnGetAsync(Product.ProductId);
                }

                var existingProduct = await existingResponse.Content.ReadFromJsonAsync<ProductViewModel>();

                // Preserve all fields except QuantityInStock
                Product.ProductName = existingProduct.ProductName;
                Product.Description = existingProduct.Description;
                Product.CategoryId = existingProduct.CategoryId;
                Product.SupplierId = existingProduct.SupplierId;
            }

            AddJwtTokenToHeader();
            var response = await _httpClient.PutAsJsonAsync($"api/product/{Product.ProductId}", Product);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Product updated successfully";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            ModelState.AddModelError(string.Empty, "Error updating product. Please try again.");
            return await OnGetAsync(Product.ProductId); // reload dropdowns
        }


        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
