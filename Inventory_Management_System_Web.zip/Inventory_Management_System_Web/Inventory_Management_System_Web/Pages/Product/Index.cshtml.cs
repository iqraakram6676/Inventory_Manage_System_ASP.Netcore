using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Product
{
    public class IndexModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public List<ProductViewModel> Products { get; set; } = new();
        public List<CategoryViewModel> Categories { get; set; } = new();
        public List<SupplierViewModel> Suppliers { get; set; } = new();

        public IndexModel(IHttpClientFactory httpClientFactory,
                          IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnGetAsync()
        {
            try
            {
                await AddJwtTokenToHeader();

                // Fetch products
                var productResponse = await _httpClient.GetAsync("api/product");
                if (productResponse.IsSuccessStatusCode)
                {
                    Products = await productResponse.Content.ReadFromJsonAsync<List<ProductViewModel>>() ?? new List<ProductViewModel>();
                }

                // Fetch categories
                var categoryResponse = await _httpClient.GetAsync("api/category");
                if (categoryResponse.IsSuccessStatusCode)
                {
                    Categories = await categoryResponse.Content.ReadFromJsonAsync<List<CategoryViewModel>>() ?? new List<CategoryViewModel>();
                }

                // Fetch suppliers
                var supplierResponse = await _httpClient.GetAsync("api/supplier");
                if (supplierResponse.IsSuccessStatusCode)
                {
                    Suppliers = await supplierResponse.Content.ReadFromJsonAsync<List<SupplierViewModel>>() ?? new List<SupplierViewModel>();
                }

                // Map names
                foreach (var product in Products)
                {
                    product.CategoryName = Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId)?.CategoryName ?? "N/A";
                    product.SupplierName = Suppliers.FirstOrDefault(s => s.SupplierId == product.SupplierId)?.SupplierName ?? "N/A";
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error: {ex.Message}";
            }
        }

        private async Task AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
