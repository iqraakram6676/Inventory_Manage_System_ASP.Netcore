using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Role
{
    public class DeleteModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public RoleViewModel Role { get; set; } = new();

        public DeleteModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.GetAsync($"api/role/{id}");
            if (response.IsSuccessStatusCode)
            {
                Role = await response.Content.ReadFromJsonAsync<RoleViewModel>();
                return Page();
            }

            TempData["ErrorMessage"] = "Role not found.";
            return RedirectToPage("Index");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.DeleteAsync($"api/role/{Role.RoleId}");
            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Role deleted successfully.";
                return RedirectToPage("Index");
            }

            TempData["ErrorMessage"] = "Error deleting role. Please try again.";
            return RedirectToPage("Index");
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
