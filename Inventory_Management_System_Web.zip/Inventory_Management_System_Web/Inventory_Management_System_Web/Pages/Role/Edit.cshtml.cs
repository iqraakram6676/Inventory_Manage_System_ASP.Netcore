using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Role
{
    public class EditModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public RoleViewModel Role { get; set; } = new();

        public EditModel(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            await AddJwtTokenToHeader();

            var roleData = await _httpClient.GetFromJsonAsync<RoleViewModel>($"api/role/{id}");
            if (roleData == null)
            {
                TempData["ErrorMessage"] = "Role not found.";
                return RedirectToPage("Index");
            }

            Role = roleData;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            await AddJwtTokenToHeader();

            var response = await _httpClient.PutAsJsonAsync($"api/role/{Role.RoleId}", Role);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Role updated successfully";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToPage("/Login");
            }

            ModelState.AddModelError(string.Empty, "Error updating role.");
            return Page();
        }

        private async Task AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");

            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
