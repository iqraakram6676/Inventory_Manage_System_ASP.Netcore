using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.Supplier
{
    public class DeleteModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public SupplierViewModel Supplier { get; set; } = new();

        public DeleteModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.GetAsync($"api/supplier/{id}");
            if (response.IsSuccessStatusCode)
            {
                Supplier = await response.Content.ReadFromJsonAsync<SupplierViewModel>() ?? new SupplierViewModel();
                return Page();
            }

            TempData["ErrorMessage"] = "Supplier not found.";
            return RedirectToPage("Index");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            AddJwtTokenToHeader();

            var response = await _httpClient.DeleteAsync($"api/supplier/{Supplier.SupplierId}");
            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "Supplier deleted successfully.";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            TempData["ErrorMessage"] = "Error deleting supplier. Please try again.";
            return RedirectToPage("Index");
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
