using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.User
{
    public class CreateModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public UserViewModel User { get; set; } = new();

        // List for dropdown
        public List<SelectListItem> RoleOptions { get; set; } = new();

        public CreateModel(IHttpClientFactory httpClientFactory,
                           IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnGetAsync()
        {
            AddJwtTokenToHeader();

            // Fetch roles from API
            var response = await _httpClient.GetAsync("api/role");
            if (response.IsSuccessStatusCode)
            {
                var roles = await response.Content.ReadFromJsonAsync<List<RoleViewModel>>();
                RoleOptions = roles.Select(r => new SelectListItem
                {
                    Value = r.RoleId.ToString(),
                    Text = r.RoleName
                }).ToList();
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await OnGetAsync(); // reload roles if validation fails
                return Page();
            }

            AddJwtTokenToHeader();

            var response = await _httpClient.PostAsJsonAsync("api/user", User);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "User created successfully.";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            ModelState.AddModelError(string.Empty, "Error creating user. Please try again.");
            await OnGetAsync(); // reload roles
            return Page();
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
