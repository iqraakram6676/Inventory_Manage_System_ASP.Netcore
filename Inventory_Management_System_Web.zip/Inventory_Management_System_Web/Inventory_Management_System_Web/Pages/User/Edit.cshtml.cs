using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.User
{
    public class EditModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        [BindProperty]
        public UserViewModel User { get; set; } = new();

        // For dropdown
        public List<SelectListItem> RoleOptions { get; set; } = new();

        public EditModel(IHttpClientFactory httpClientFactory,
                         IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AddJwtTokenToHeader();

            // Get user
            var response = await _httpClient.GetAsync($"api/user/{id}");
            if (response.IsSuccessStatusCode)
            {
                User = await response.Content.ReadFromJsonAsync<UserViewModel>();
            }
            else
            {
                TempData["ErrorMessage"] = "User not found.";
                return RedirectToPage("Index");
            }

            // Get all roles
            var rolesResponse = await _httpClient.GetAsync("api/role");
            if (rolesResponse.IsSuccessStatusCode)
            {
                var roles = await rolesResponse.Content.ReadFromJsonAsync<List<RoleViewModel>>();
                RoleOptions = roles.Select(r => new SelectListItem
                {
                    Value = r.RoleId.ToString(),
                    Text = r.RoleName,
                    Selected = r.RoleId == User.RoleId
                }).ToList();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            AddJwtTokenToHeader();

            var response = await _httpClient.PutAsJsonAsync($"api/user/{User.UserId}", User);

            if (response.IsSuccessStatusCode)
            {
                TempData["SuccessMessage"] = "User updated successfully";
                return RedirectToPage("Index");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                TempData["ErrorMessage"] = "Session expired. Please login again.";
                return RedirectToPage("/Home/Login");
            }

            ModelState.AddModelError(string.Empty, "Error updating user. Please try again.");
            return Page();
        }

        private void AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
