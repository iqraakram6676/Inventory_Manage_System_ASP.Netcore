using Inventory_Management_System_Web.Pages.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Inventory_Management_System_Web.Pages.User
{
    public class IndexModel : PageModel
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public List<UserViewModel> Users { get; set; } = new();
        public List<RoleViewModel> Roles { get; set; } = new(); // store roles

        public IndexModel(IHttpClientFactory httpClientFactory,
                          IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient("InventoryApi");
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task OnGetAsync()
        {
            await AddJwtTokenToHeader();

            // Get users
            var userResponse = await _httpClient.GetAsync("api/user");
            if (userResponse.IsSuccessStatusCode)
            {
                Users = await userResponse.Content.ReadFromJsonAsync<List<UserViewModel>>() ?? new List<UserViewModel>();
            }

            // Get roles
            var roleResponse = await _httpClient.GetAsync("api/role");
            if (roleResponse.IsSuccessStatusCode)
            {
                Roles = await roleResponse.Content.ReadFromJsonAsync<List<RoleViewModel>>() ?? new List<RoleViewModel>();
            }

            // Map RoleId -> RoleName
            foreach (var user in Users)
            {
                var role = Roles.FirstOrDefault(r => r.RoleId == user.RoleId);
                user.RoleName = role?.RoleName ?? "N/A";
            }
        }

        private async Task AddJwtTokenToHeader()
        {
            var token = _httpContextAccessor.HttpContext?.Session.GetString("JwtToken");
            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
