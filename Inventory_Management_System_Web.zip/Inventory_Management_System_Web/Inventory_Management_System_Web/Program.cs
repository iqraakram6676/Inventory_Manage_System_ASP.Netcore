using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using System.Net.Http.Headers;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddRazorPages(options =>
{

    var policy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
    options.Conventions.AuthorizeFolder("/"); // Poora site protected
    options.Conventions.AllowAnonymousToPage("/Home/Login"); // Login page allow
    options.Conventions.AllowAnonymousToPage("/Home/AccessDenied"); // Access Denied page allow
    options.Conventions.AllowAnonymousToPage("/Home/Logout"); // Logout page allow
})
.AddRazorPagesOptions(opt =>
{
    // Aap custom authorization yahan bhi add kar sakte ho agar zarurat ho
});

// ? Cookie Authentication
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Home/Login";
        options.LogoutPath = "/Home/Logout";
        options.AccessDeniedPath = "/Home/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    });

builder.Services.AddHttpContextAccessor();

// ? Distributed cache & session
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// ? Register HttpClient for API calls
builder.Services.AddHttpClient("InventoryApi", client =>
{
    client.BaseAddress = new Uri("https://localhost:7219/"); // Your API base URL
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
});

// ? Allow Razor Pages to call API (CORS)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowInventoryApp", policy =>
    {
        policy.WithOrigins("https://localhost:5001") // Change if Razor runs on different port
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// ? Enable CORS
app.UseCors("AllowInventoryApp");

// ? Error handling & HSTS
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// ? Disable browser caching (logout ke baad back button se old pages na khule)
app.Use(async (context, next) =>
{
    context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    context.Response.Headers["Pragma"] = "no-cache";
    context.Response.Headers["Expires"] = "0";
    await next();
});

app.UseAuthentication();
app.UseAuthorization();

app.UseSession();

// ? Redirect root to login
app.MapGet("/", context =>
{
    context.Response.Redirect("/Home/Login");
    return Task.CompletedTask;
});

// ? Razor Pages mapping
app.MapRazorPages();

app.Run();
