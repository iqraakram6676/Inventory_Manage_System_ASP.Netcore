﻿namespace Inventory_Management_System_Web.Pages.ViewModels
{
    public class CategoryViewModel
    {
        public int CategoryId { get; set; }  // matches the entity's primary key
        public string CategoryName { get; set; } = string.Empty; // required
        public string Description { get; set; } = string.Empty;  // optional
    }
}
