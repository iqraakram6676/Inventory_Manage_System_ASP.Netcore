﻿namespace Inventory_Management_System_Web.Pages.ViewModels
{
    public class RoleViewModel
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; } = string.Empty;
    }
}
