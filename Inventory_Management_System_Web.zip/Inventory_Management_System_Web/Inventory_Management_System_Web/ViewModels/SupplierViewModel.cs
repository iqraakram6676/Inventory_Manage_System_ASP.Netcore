﻿namespace Inventory_Management_System_Web.Pages.ViewModels
{
    public class SupplierViewModel
    {
        public int SupplierId { get; set; }  // matches the entity's primary key
        public string SupplierName { get; set; } = string.Empty;  // required
        public string ContactInfo { get; set; } = string.Empty;   // optional
        public string Address { get; set; } = string.Empty;       // optional
    }
}
